module Api
  class CardAssignmentsController < ApiController
  end
end
