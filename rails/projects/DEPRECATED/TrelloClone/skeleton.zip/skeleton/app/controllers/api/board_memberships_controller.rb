module Api
  class BoardMembershipsController < ApiController
  end
end
